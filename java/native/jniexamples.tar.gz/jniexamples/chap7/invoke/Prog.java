public class Prog {
    public static void main(String[] args) {
         System.out.println("Hello World " + args[0]);
    }
}
